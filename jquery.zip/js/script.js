numeros = [];
for (i=0;i<10;i++){
    numeros.push(i);
}
var generarNumero = function(){
    return Math.floor(Math.random() * (11 - 0)) + 0;
}
$("#numero1").append(generarNumero);
$("#numero2").append(generarNumero);
$("#numero3").append(generarNumero);
//Hacer los numeros arraztrables
$(".numero").draggable({
    helper: "clone",
    cursor: 'move'
});

$("#comprobarResultado").click(function(){
    console.log("click")
});

$("#numero1").droppable({
    accept: ".numero",
drop: function (event, ui) {
        var canvas = $(this);
        if (!ui.draggable.hasClass('canvas-element')) {
            var canvasElement = ui.draggable.clone();
            canvasElement.addClass('canvas-element');
            canvasElement.draggable({
                containment: '#elementos'
            });
            canvas.append(canvasElement);
            canvasElement.css({
                left: (ui.position.left),
                top: (ui.position.top),
                position: 'absolute'
            });
        }
    }
    //drop: function( event, ui ) {
    //    console.log("Soltado")
     // }
})
$("#numero2").droppable({
    accept: ".numero",
    drop: function (event, ui) {
        var canvas = $(this);
        if (!ui.draggable.hasClass('canvas-element')) {
            var canvasElement = ui.draggable.clone();
            canvasElement.addClass('canvas-element');
            canvasElement.draggable({
                containment: '#elementos'
            });
            canvas.append(canvasElement);
            canvasElement.css({
                left: (ui.position.left),
                top: (ui.position.top),
                position: 'absolute'
            });
        }
    }
})
$("#numero3").droppable({
    accept: ".numero",
    drop: function (event, ui) {
        var canvas = $(this);
        if (!ui.draggable.hasClass('canvas-element')) {
            var canvasElement = ui.draggable.clone();
            canvasElement.addClass('canvas-element');
            canvasElement.draggable({
                containment: '#elementos'
            });
            canvas.append(canvasElement);
            canvasElement.css({
                left: (ui.position.left),
                top: (ui.position.top),
                position: 'absolute'
            });
        }
    }

})