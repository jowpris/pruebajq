//Lleno un arreglo con los numeros 0-9
numeros = [];
for (i=0;i<10;i++){
    numeros.push(i);
}
//Guarda los numeros arrastrados
numerosArrastrados = [];
numerosGenerados = [];
//Genera un numero random entre 0-9
var generarNumero = function(){
    return Math.floor(Math.random() * (11 - 0)) + 0;
}
numerosGenerados[0]= generarNumero();
numerosGenerados[1]= generarNumero();
numerosGenerados[2]= generarNumero();
//A los elementos #numero1,#numero2y#numero3 les agrega el numero generado
$("#numero1").append(numerosGenerados[0]);
$("#numero2").append(numerosGenerados[1]);
$("#numero3").append(numerosGenerados[2]);

//Todos los elementos con clase numero lo hacemos arraztrable
$(".numero").draggable({
    helper: "clone",
    cursor: 'move'
});
//Funcion para comprobar el resultado
$("#comprobarResultado").click(function(){
    //console.log("click")
    //$("#fail")[0].play();

    if(numerosGenerados[0]==numerosArrastrados[0] &&
        numerosGenerados[1]==numerosArrastrados[1] &&
        numerosGenerados[2]==numerosArrastrados[2] ){
            $("#bien")[0].play(); //reproduce el audio
    }else{
        $("#fail")[0].play(); //reproduce el audio
    }
});
//Caja que tiene el numero1 generado y donde se puede soltar los numeros
$("#numero1").droppable({
    accept: ".numero",
    drop: function (event, ui) { //Esta funcion se lanza cuando se suelta un numero
            var canvas = $(this);
            if (!ui.draggable.hasClass('canvas-element')) {
                var canvasElement = ui.draggable.clone();
                canvasElement.addClass('canvas-element');
                canvasElement.draggable({
                    containment: '#elementos'
                });
                canvas.append(canvasElement);
                canvasElement.css({
                    left: (ui.position.left),
                    top: (ui.position.top),
                    position: 'absolute'
                });
                numerosArrastrados[0] = canvasElement.attr("id"); //Guarda el numero soltado
            }
        }
})
//Caja que tiene el numero2 generado y donde se puede soltar los numeros
$("#numero2").droppable({
    accept: ".numero",
    drop: function (event, ui) { //Esta funcion se lanza cuando se suelta un numero
        var canvas = $(this);
        if (!ui.draggable.hasClass('canvas-element')) {
            var canvasElement = ui.draggable.clone();
            canvasElement.addClass('canvas-element');
            canvasElement.draggable({
                containment: '#elementos'
            });
            canvas.append(canvasElement);
            canvasElement.css({
                left: (ui.position.left),
                top: (ui.position.top),
                position: 'absolute'
            });
            numerosArrastrados[1] = canvasElement.attr("id"); ////Guarda el numero soltado
        }
    }
})
//Caja que tiene el numero3 generado y donde se puede soltar los numeros
$("#numero3").droppable({
    accept: ".numero",
    drop: function (event, ui) { //Esta funcion se lanza cuando se suelta un numero
        var canvas = $(this);
        if (!ui.draggable.hasClass('canvas-element')) {
            var canvasElement = ui.draggable.clone();
            canvasElement.addClass('canvas-element');
            canvasElement.draggable({
                containment: '#elementos'
            });
            canvas.append(canvasElement);
            canvasElement.css({
                left: (ui.position.left),
                top: (ui.position.top),
                position: 'absolute'
            });
            numerosArrastrados[2] = canvasElement.attr("id"); ////Guarda el numero soltado
        }
    }
})