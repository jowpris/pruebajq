numeros = [];
for (i=0;i<10;i++){
    numeros.push(i);
}
var generarNumero = function(){
    return Math.floor(Math.random() * (11 - 0)) + 0;
}

//Hacer los numeros arraztrables
$(".numero").draggable({
    helper: "clone",
    cursor: 'move'
});

$("#comprobarResultado").click(function(){
    console.log("click")
})

$("#elementos").droppable({
    drop: function (event, ui) {

        var canvas = $(this);

        if (!ui.draggable.hasClass('canvas-element')) {
            var canvasElement = ui.draggable.clone();
            canvasElement.addClass('canvas-element');

            //canvasElement.attr('id', generarId);

            canvasElement.draggable({
                containment: '#elementos'
            });
            canvas.append(canvasElement);
            canvasElement.css({
                left: (ui.position.left),
                top: (ui.position.top),
                position: 'absolute'
            });


        }
    }
});